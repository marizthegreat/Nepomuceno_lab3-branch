import React, { useState } from 'react';
import { View, Text, TextInput, FlatList, StyleSheet, TouchableOpacity } from 'react-native';
import { useFonts, Poppins_400Regular, Poppins_600SemiBold } from '@expo-google-fonts/poppins';

export default function App() {
  const [brand, setBrand] = useState('');
  const [brandList, setBrandList] = useState([]);

  let [fontsLoaded] = useFonts({
    Poppins_400Regular,
    Poppins_600SemiBold,
  });

  const addBrand = () => {
    if (brand.trim() !== '') {
      setBrandList([...brandList, { key: Math.random().toString(), name: brand }]);
      setBrand('');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>My Favorite Makeup & Skincare Brands 💄</Text>
      <Text style={styles.subtitle}>
        Add your go-to brands below!
      </Text>

      <TextInput
        style={styles.input}
        placeholder="Enter Item"
        placeholderTextColor="#b57edc"
        value={brand}
        onChangeText={setBrand}
      />

      <TouchableOpacity style={styles.addButton} onPress={addBrand}>
        <Text style={styles.addButtonText}>Add Brand</Text>
      </TouchableOpacity>

      <FlatList
        data={brandList}
        renderItem={({ item }) => (
          <View style={styles.listItem}>
            <Text style={styles.listText}>✨ {item.name}</Text>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff0f5',
    padding: 20,
    paddingTop: 60,
  },
  title: {
    fontSize: 26,
    fontFamily: 'Poppins_600SemiBold',
    color: '#d36ac2',
    textAlign: 'center',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Poppins_400Regular',
    color: '#b57edc',
    textAlign: 'center',
    marginBottom: 20,
  },
  input: {
    borderWidth: 2,
    borderColor: '#ffb6c1',
    borderRadius: 15,
    padding: 12,
    backgroundColor: '#fff',
    fontSize: 16,
    fontFamily: 'Poppins_400Regular',
    marginBottom: 10,
  },
  addButton: {
    backgroundColor: '#ffb6c1',
    padding: 12,
    borderRadius: 15,
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#b57edc',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  addButtonText: {
    color: '#fff',
    fontSize: 18,
    fontFamily: 'Poppins_600SemiBold',
  },
  listItem: {
    backgroundColor: '#ffe4f3',
    padding: 12,
    borderRadius: 12,
    marginBottom: 10,
  },
  listText: {
    fontSize: 18,
    fontFamily: 'Poppins_400Regular',
    color: '#d36ac2',
  },
});
